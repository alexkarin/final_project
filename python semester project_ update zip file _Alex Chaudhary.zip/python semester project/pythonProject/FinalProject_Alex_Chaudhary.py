from tkinter import *

# Start Button <--------

# -print- Game Rules
# -print- In this game 2 players throw a choice simultaneously  Rock,  Paper,  or  Scissors.
#
# -print- The rules of the game are  simple:
#  rock beats scissors
# paper beats rock
# scissors beats paper
#  If players choose the same it is a draw and no points are awarded
# You will play against the computer, the computer is not AI (yet) so  will choose at random.
###### choose number of rounds, quit button, or play infinitly.   still add quit button
#### keep track of score but clear last rounds choice
# i dont like the text box, id rather have something like " x wins"  and an update on score count
# contents of window should expand with window

import random

import tkinter as tk



# game class that handles all scores, and player moves ------
class game:
    def __init__(self):
        self._name = None
        self.playerScore = 0
        self.computerScore = 0
        self.draw = 0

    def display(self, name):
        self._name = name
        print(self._name)
        textWindow.insert(1.0, "Your choice: {}".format(name) + '\n')

    def playComputer(self, window, player):
        options = ["rock", "paper", "scissors"]
        num = random.randint(0, 2)
        textWindow.insert(1.0, "Computers choice: {}".format(options[num] + '\n'))
        textWindow.insert(1.0, player + '\n')

        # score lable for computer
        computerLabel = Label(window, text=" Computer: ")
        computerLabel.place(x=130, y=130)
        # score lable for Player, can this be users name?
        playerLabel = Label(window, text=" Player: ")
        playerLabel.place(x=250, y=130)
        # number of draws that occured
        drawLabel = Label(window, text="Draw: ")
        # playerLabel.place(x=100,y=120)

        if player == "rock" and options[num] == "scissors":
            self.playerScore = self.playerScore + 1
            textWindow.insert(1.0, "Player beat computer with ", player + '\n')
            playerLabel['text'] = ("Player: ", self.playerScore)

        elif player == "rock" and options[num] == "paper":
            self.computerScore = self.computerScore + 1
            textWindow.insert(1.0, "Computer beat player with ", player + '\n')
            computerLabel['text'] = ("Computer: ", self.computerScore)

        elif player == "rock" and options[num] == "rock":
            textWindow.insert(1.0, "Draw" + '\n')
            self.draw = self.draw + 1
            drawLabel['text'] = ("draw: ", self.draw)
        elif player == "paper" and options[num] == "rock":
            self.playerScore = self.playerScore + 1
            playerLabel['text'] = ("Player: ", self.playerScore)
            textWindow.insert(1.0, "Player beat computer with ", player + '\n')
###### There is a problem here, it seems if both the player and the computer choose rock  the gui prints the computer choice..

        elif player == "paper" and options[num] == "paper":
            textWindow.insert(1.0, "Draw" + '\n')
            self.draw = self.draw + 1
            drawLabel['text'] = ("draw: ", self.draw)
        elif player == "paper" and options[num] == "scissors":
            self.computerScore = self.computerScore + 1

            computerLabel['text'] = ("Computer: ", self.computerScore)
            textWindow.insert(1.0, "Computer beat player with ", player + '\n')
        elif player == "scissors" and options[num] == "rock":
            self.computerScore = self.computerScore + 1

            computerLabel['text'] = ("Computer: ", self.computerScore)
            textWindow.insert(1.0, "Computer beat player with ", player + '\n')
        elif player == "scissors" and options[num] == "paper":
            self.playerScore = self.playerScore + 1

            playerLabel['text'] = ("Player: ", self.playerScore)
            textWindow.insert(1.0, "Player beat computer with ", player + '\n')
        else:
            textWindow.insert(1.0, "Draw" + '\n')
            self.draw = self.draw + 1
            drawLabel['text'] = ("draw: ", self.draw)


# Creates a window
window = Tk()
# labels the window
window.title("Rock Paper Scissors")
# sets the window size
window.geometry("400x400")
# changes the background color
window.configure(bg='light gray')
# instance of the game class
g = game()
# Creates a rock button
# lambda will execute commands one by one
rockButton = Button(window, text="  Rock  ", fg='white', bg='blue',
                    command=lambda: [g.display("rock"), g.playComputer(window, "rock")])
### rock = Image.open("C:\Users\there\OneDrive\Desktop\python semester project\images\Rock.png")
# places rock  the button
rockButton.place(x=88, y=100)
# Creates a paper button
paperButton = Button(window, text="  Paper ", fg='white', bg='dark violet',
                     command=lambda: [g.display("paper"), g.playComputer(window, "paper")])
### paper = Image.open("C:\Users\there\OneDrive\Desktop\python semester project\images\Paper.png
# places the paper button
paperButton.place(x=170, y=100)
# Creates a scissors button
scissorsButton = Button(window, text="Scissors", fg='white', bg='green',
                        command=lambda: [g.display("scissors"), g.playComputer(window, "scissors")])
### scissors = Image.open("C:\Users\there\OneDrive\Desktop\python semester project\images\scisso
# places the scissors button
scissorsButton.place(x=250, y=100)
# creates a text widget
textWindow = Text(window, height=10, width=43)
# places the text widget
textWindow.place(x=25, y=160)

##Button to reset the Game##

window.mainloop()

